//
//  ViewController.m
//  Body Mass Index
//
//  Created by soyea on 16/3/25.
//  Copyright © 2016年 lyf. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doAction:(UIButton *)sender {
    float w = [_wText.text intValue];
    float h = [_heightText.text intValue];
    float resultNumber = w / powf((h/100), 2);
    _resultNumber.text = [NSString stringWithFormat:@"%.1f",resultNumber];
    if (resultNumber <= 18.4 ) {
    _resultString.text = @"偏瘦";
        _resultString.textColor = [UIColor lightGrayColor];
    }else if(resultNumber <= 23.9){
    _resultString.text = @"正常";
        _resultString.textColor = [UIColor greenColor];
    }else if (resultNumber < 28.0){
    _resultString.text = @"过重";
        _resultString.textColor = [UIColor brownColor];

    }else if(resultNumber < 35){
    _resultString.text = @"轻度肥胖";
        _resultString.textColor = [UIColor orangeColor];

    }else{
    _resultString.text = @"重度肥胖";
        _resultString.textColor = [UIColor redColor];


    }
   
}
@end
