//
//  ViewController.h
//  Body Mass Index
//
//  Created by soyea on 16/3/25.
//  Copyright © 2016年 lyf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *heightText;
@property (weak, nonatomic) IBOutlet UITextField *wText;

- (IBAction)doAction:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UILabel *resultNumber;
@property (weak, nonatomic) IBOutlet UILabel *resultString;
@end

